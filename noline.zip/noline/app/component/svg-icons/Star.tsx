
interface StarProps {
    className?: string;
}

const Star = ({ className }: StarProps) => {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="19" viewBox="0 0 20 19" fill="none" className={className}>
            <path d="M3.825 19L5.45 11.975L0 7.25L7.2 6.625L10 0L12.8 6.625L20 7.25L14.55 11.975L16.175 19L10 15.275L3.825 19Z" fill="currentColor" />
        </svg>
    )
}

export default Star